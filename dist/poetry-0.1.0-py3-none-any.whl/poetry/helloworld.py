print("helloworld")

def print_hello():
    print("Hello Gysssss:)")